package com.madcat.nsd_chat;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.net.ServerSocket;

public class NSD_MainActivity extends AppCompatActivity {
    static final int SocketServerPORT = 8080;  // Port should be fetched dynamically in real systems.// NSD Manager and service registration code
    private String SERVICE_NAME = "Test Server Device";
    private String SERVICE_TYPE = "_http._tcp.";
    private NsdManager mNsdManager;
//Initialize other variable that you will need

    ServerSocket serverSocket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nsd__main);
        //Fetch other Components
        mNsdManager = (NsdManager) getSystemService(Context.NSD_SERVICE);
       registerService(SocketServerPORT);

    }




@Override
protected void onResume() {
        super.onResume();
        if (mNsdManager == null) {
        registerService(SocketServerPORT);
        }

        }

@Override
protected void onDestroy() {
        super.onDestroy();

        if (serverSocket != null) {
        try {
        serverSocket.close();
        } catch (IOException e) {
        e.printStackTrace();
        }
        }
        }

public void registerService(int port) {
        NsdServiceInfo serviceInfo = new NsdServiceInfo();
        serviceInfo.setServiceName(SERVICE_NAME);
        serviceInfo.setServiceType(SERVICE_TYPE);
        serviceInfo.setPort(port);

        mNsdManager.registerService(serviceInfo,
        NsdManager.PROTOCOL_DNS_SD,
        mRegistrationListener);
        }

        NsdManager.RegistrationListener mRegistrationListener = new NsdManager.RegistrationListener() {

@Override
public void onServiceRegistered(NsdServiceInfo NsdServiceInfo) {
        String mServiceName = NsdServiceInfo.getServiceName();
        SERVICE_NAME = mServiceName;
        Toast.makeText(NSD_MainActivity.this, "Successfully registered",
        Toast.LENGTH_LONG).show();
        Log.d("NsdserviceOnRegister", "Registered name : " + mServiceName);
        }

@Override
public void onRegistrationFailed(NsdServiceInfo serviceInfo,
        int errorCode) {

        Toast.makeText(NSD_MainActivity.this, "registration failed",
        Toast.LENGTH_LONG).show();
        }

@Override
public void onServiceUnregistered(NsdServiceInfo serviceInfo) {
        // NsdManager.unregisterService() called and passed in this listener.
        Log.d("NsdserviceOnUnregister",
        "Service Unregistered : " + serviceInfo.getServiceName());
        }

@Override
public void onUnregistrationFailed(NsdServiceInfo serviceInfo,
        int errorCode) {
        //Fail
        }
        };
        }
