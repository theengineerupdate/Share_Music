package com.madcat.nsd_chat;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    Button button_Server, button_Client;
    TextView textView_1, textView_2;

    int arr[]={1,2,3,4,5,6,7,8,9,0};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_Server=findViewById(R.id.button_Server);
        button_Client=findViewById(R.id.button_Client);

        button_Server.setOnClickListener(this);
        button_Client.setOnClickListener(this);


        textView_1=findViewById(R.id.textView_1);
        textView_2=findViewById(R.id.textView_2);

        textView_1.setText(printArr(arr));

        int n=-3;

        if(n>=0){
        for(int j =0; j<n; j++){

            int tmp =arr[arr.length-1];
            for(int i=0; i<arr.length-1;i++){
                arr[arr.length-1-i]=arr[arr.length-1-i-1];

            }
            arr[0]=tmp;
        }}
        else{
            for(int j =0; j<(n*(-1)); j++){

                int tmp =arr[0];
                for(int i=1; i<arr.length;i++){
                    arr[i-1]=arr[i];

                }
                arr[arr.length-1]=tmp;
            }

        }


        textView_2.setText(printArr(arr));




    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){

            case  R.id.button_Server:

                startActivity(new Intent(MainActivity.this, NSD_MainActivity.class));

                break;

            case R.id.button_Client:

                startActivity(new Intent( MainActivity.this,NSDClientSide.class));

                break;



        }
    }

    public static String printArr(int arr[]){
        String string="";
        for(int i=0; i<arr.length;i++){
            string=string+arr[i];
        }

        return string;
    }
}
